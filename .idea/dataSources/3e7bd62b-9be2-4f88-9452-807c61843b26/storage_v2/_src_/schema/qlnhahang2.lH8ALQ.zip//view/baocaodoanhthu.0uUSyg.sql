create definer = root@localhost view baocaodoanhthu as
select `qlnhahang2`.`hoadonban`.`MaHoaDon` AS `MaHoaDon`,
       `qlnhahang2`.`user`.`Ten`           AS `Ten`,
       `qlnhahang2`.`hoadonban`.`NgayLap`  AS `NgayLap`
from (`qlnhahang2`.`user` join `qlnhahang2`.`hoadonban`
      on ((`qlnhahang2`.`hoadonban`.`userId` = `qlnhahang2`.`user`.`userId`)));

