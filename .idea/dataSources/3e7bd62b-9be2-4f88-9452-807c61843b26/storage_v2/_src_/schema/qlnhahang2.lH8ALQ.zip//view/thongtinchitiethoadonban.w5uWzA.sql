create definer = root@localhost view thongtinchitiethoadonban as
select `qlnhahang2`.`hoadonban`.`MaHoaDon`       AS `MaHoaDon`,
       `qlnhahang2`.`danhmucsp`.`TenSP`          AS `TenSP`,
       `qlnhahang2`.`chitiethoadon`.`SoLuong`    AS `SoLuong`,
       `qlnhahang2`.`chitiethoadon`.`TongTienHD` AS `TongTienHD`
from ((`qlnhahang2`.`hoadonban` join `qlnhahang2`.`chitiethoadon` on ((`qlnhahang2`.`chitiethoadon`.`MaHoaDon` =
                                                                       `qlnhahang2`.`hoadonban`.`MaHoaDon`))) join `qlnhahang2`.`danhmucsp`
      on ((`qlnhahang2`.`danhmucsp`.`MaSP` = `qlnhahang2`.`chitiethoadon`.`MaSP`)));

