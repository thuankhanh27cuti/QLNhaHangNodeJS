create definer = root@localhost view baocaohoadonnhap as
select `qlnhahang2`.`hoadonnhap`.`MaHoaDonNhap` AS `MaHoaDonNhap`,
       `qlnhahang2`.`hoadonnhap`.`NgayNhapHang` AS `NgayNhapHang`,
       `qlnhahang2`.`user`.`Ho`                 AS `Ho`,
       `qlnhahang2`.`user`.`Ten`                AS `Ten`
from (`qlnhahang2`.`hoadonnhap` join `qlnhahang2`.`user`
      on ((`qlnhahang2`.`hoadonnhap`.`userId` = `qlnhahang2`.`user`.`userId`)));

