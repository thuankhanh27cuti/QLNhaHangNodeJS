create definer = root@localhost view thongtinchitiethoadonban as
select `qlnhahangv3`.`hoadonban`.`MaHoaDon`       AS `MaHoaDon`,
       `qlnhahangv3`.`danhmucsp`.`TenSP`          AS `TenSP`,
       `qlnhahangv3`.`chitiethoadon`.`SoLuong`    AS `SoLuong`,
       `qlnhahangv3`.`chitiethoadon`.`TongTienHD` AS `TongTienHD`
from ((`qlnhahangv3`.`hoadonban` join `qlnhahangv3`.`chitiethoadon` on ((`qlnhahangv3`.`chitiethoadon`.`MaHoaDon` =
                                                                         `qlnhahangv3`.`hoadonban`.`MaHoaDon`))) join `qlnhahangv3`.`danhmucsp`
      on ((`qlnhahangv3`.`danhmucsp`.`MaSP` = `qlnhahangv3`.`chitiethoadon`.`MaSP`)));

