create definer = root@localhost view baocaohoadonnhap as
select `qlnhahangv3`.`hoadonnhap`.`MaHoaDonNhap` AS `MaHoaDonNhap`,
       `qlnhahangv3`.`hoadonnhap`.`NgayNhapHang` AS `NgayNhapHang`,
       `qlnhahangv3`.`user`.`Ho`                 AS `Ho`,
       `qlnhahangv3`.`user`.`Ten`                AS `Ten`
from (`qlnhahangv3`.`hoadonnhap` join `qlnhahangv3`.`user`
      on ((`qlnhahangv3`.`hoadonnhap`.`userId` = `qlnhahangv3`.`user`.`userId`)));

