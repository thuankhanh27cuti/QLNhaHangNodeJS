create definer = root@localhost view baocaodoanhthu as
select `qlnhahangv3`.`hoadonban`.`MaHoaDon` AS `MaHoaDon`,
       `qlnhahangv3`.`user`.`Ten`           AS `Ten`,
       `qlnhahangv3`.`hoadonban`.`NgayLap`  AS `NgayLap`
from (`qlnhahangv3`.`user` join `qlnhahangv3`.`hoadonban`
      on ((`qlnhahangv3`.`hoadonban`.`userId` = `qlnhahangv3`.`user`.`userId`)));

