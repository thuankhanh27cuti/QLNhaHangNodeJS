create definer = root@localhost view thongtinhoadonnhap as
select `qlnhahangv3`.`hoadonnhap`.`MaHoaDonNhap`    AS `MaHoaDonNhap`,
       `qlnhahangv3`.`user`.`Ho`                    AS `Ho`,
       `qlnhahangv3`.`user`.`Ten`                   AS `Ten`,
       `qlnhahangv3`.`hoadonnhap`.`NgayNhapHang`    AS `NgayNhapHang`,
       `qlnhahangv3`.`chitiethoadonnhap`.`TongTien` AS `TongTien`
from ((`qlnhahangv3`.`hoadonnhap` join `qlnhahangv3`.`user`
       on ((`qlnhahangv3`.`user`.`userId` = `qlnhahangv3`.`hoadonnhap`.`userId`))) join `qlnhahangv3`.`chitiethoadonnhap`
      on ((`qlnhahangv3`.`chitiethoadonnhap`.`MaHoaDonNhap` = `qlnhahangv3`.`hoadonnhap`.`MaHoaDonNhap`)));

